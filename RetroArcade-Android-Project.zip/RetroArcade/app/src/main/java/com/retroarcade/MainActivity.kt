package com.retroarcade

import android.app.Activity
import android.os.Bundle
import android.view.WindowManager

class MainActivity : Activity() {
    private lateinit var gameView: ArcadeView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        gameView = ArcadeView(this)
        setContentView(gameView)
    }

    override fun onPause() {
        gameView.pauseForLifecycle()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        gameView.resumeForLifecycle()
    }

    @Deprecated("Deprecated in Android API")
    override fun onBackPressed() {
        if (!gameView.handleBack()) super.onBackPressed()
    }
}
