package com.retroarcade

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.media.AudioManager
import android.media.ToneGenerator
import android.view.MotionEvent
import android.view.View
import kotlin.math.min
import kotlin.random.Random

class ArcadeView(context: Context) : View(context) {
    private enum class Screen { HOME, SNAKE, RACE }
    private enum class Mode { READY, COUNTDOWN, PLAYING, PAUSED, OVER }

    private val prefs = context.getSharedPreferences("retro_arcade", Context.MODE_PRIVATE)
    private var screen = Screen.HOME
    private var mode = Mode.READY
    private var soundOn = prefs.getBoolean("sound", true)
    private var musicOn = prefs.getBoolean("music", true)
    private var snakeBest = prefs.getInt("snakeBest", 0)
    private var raceBest = prefs.getInt("raceBest", 0)
    private var score = 0
    private var countdown = 0f
    private var elapsed = 0f
    private var lastFrame = 0L
    private var snakeAccumulator = 0f
    private var carSpawn = 0f
    private var roadOffset = 0f
    private var lane = 1
    private var targetLane = 1
    private var playerX = 0f
    private var obstacles = mutableListOf<Obstacle>()
    private var snake = mutableListOf<Cell>()
    private var food = Cell(5, 5)
    private var direction = Cell(1, 0)
    private var queuedDirection = Cell(1, 0)
    private var tone: ToneGenerator? = null

    private val bg = Color.rgb(5, 15, 10)
    private val panel = Color.rgb(13, 30, 19)
    private val green = Color.rgb(156, 255, 87)
    private val dimGreen = Color.rgb(63, 125, 55)
    private val yellow = Color.rgb(255, 213, 79)
    private val red = Color.rgb(255, 83, 83)
    private val white = Color.rgb(224, 242, 220)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = android.graphics.Typeface.create("monospace", android.graphics.Typeface.BOLD) }

    private data class Cell(val x: Int, val y: Int)
    private data class Obstacle(var lane: Int, var y: Float, val color: Int)

    init {
        isFocusable = true
        try { tone = ToneGenerator(AudioManager.STREAM_MUSIC, 65) } catch (_: Exception) {}
    }


    private fun save() {
        prefs.edit().putInt("snakeBest", snakeBest).putInt("raceBest", raceBest)
            .putBoolean("sound", soundOn).putBoolean("music", musicOn).apply()
    }

    private fun sfx(type: Int) {
        if (!soundOn) return
        try {
            val t = when (type) {
                1 -> ToneGenerator.TONE_PROP_BEEP
                2 -> ToneGenerator.TONE_PROP_ACK
                3 -> ToneGenerator.TONE_PROP_NACK
                else -> ToneGenerator.TONE_PROP_PROMPT
            }
            tone?.startTone(t, if (type == 1) 75 else 130)
        } catch (_: Exception) {}
    }

    private fun text(c: Canvas, value: String, x: Float, y: Float, size: Float, color: Int, center: Boolean = false) {
        p.color = color
        p.textSize = size
        p.textAlign = if (center) Paint.Align.CENTER else Paint.Align.LEFT
        c.drawText(value, x, y, p)
    }

    private fun rect(c: Canvas, l: Float, t: Float, r: Float, b: Float, color: Int, radius: Float = 12f) {
        p.color = color
        c.drawRoundRect(RectF(l, t, r, b), radius, radius, p)
    }

    private fun background(c: Canvas) {
        c.drawColor(bg)
        val step = (width / 18f).coerceAtLeast(18f)
        p.color = Color.argb(22, 156, 255, 87)
        p.strokeWidth = 1f
        var x = 0f
        while (x < width) { c.drawLine(x, 0f, x, height.toFloat(), p); x += step }
        var y = 0f
        while (y < height) { c.drawLine(0f, y, width.toFloat(), y, p); y += step }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val dt = if (lastFrame == 0L) 0f else ((System.currentTimeMillis() - lastFrame) / 1000f).coerceIn(0f, 0.05f)
        lastFrame = System.currentTimeMillis()
        if (mode == Mode.COUNTDOWN) {
            countdown -= dt
            if (countdown <= 0f) mode = Mode.PLAYING
        } else if (mode == Mode.PLAYING) {
            elapsed += dt
            if (screen == Screen.SNAKE) updateSnake(dt) else updateRace(dt)
        }
        background(canvas)
        if (screen == Screen.HOME) drawHome(canvas) else if (screen == Screen.SNAKE) drawSnakeScreen(canvas) else drawRaceScreen(canvas)
        if (mode == Mode.COUNTDOWN) {
            rect(canvas, width * .28f, height * .40f, width * .72f, height * .57f, Color.argb(220, 0, 0, 0), 18f)
            text(canvas, if (countdown > 0.65f) "3" else "2", width / 2f, height * .52f, 58f, yellow, true)
        }
        if (mode == Mode.PAUSED || mode == Mode.OVER) drawOverlay(canvas)
        postInvalidateDelayed(16)
    }

    private fun drawHome(c: Canvas) {
        text(c, "RETRO", width / 2f, height * .14f, width * .105f, green, true)
        text(c, "ARCADE", width / 2f, height * .22f, width * .105f, yellow, true)
        text(c, "CLASSIC GAMES COLLECTION", width / 2f, height * .265f, width * .031f, white, true)
        val left = width * .08f; val right = width * .92f
        val top = height * .34f; val cardH = height * .18f
        rect(c, left, top, right, top + cardH, Color.rgb(15, 43, 24), 20f)
        rect(c, left, top + cardH + 22f, right, top + cardH * 2 + 22f, Color.rgb(35, 35, 19), 20f)
        text(c, "SNAKE", width * .17f, top + cardH * .48f, width * .075f, green)
        text(c, "EAT • GROW • SURVIVE", width * .17f, top + cardH * .69f, width * .027f, white)
        text(c, "BEST  $snakeBest".replace("$snakeBest", snakeBest.toString()), width * .17f, top + cardH * .88f, width * .027f, yellow)
        text(c, ">", width * .84f, top + cardH * .65f, 42f, green, true)
        val t2 = top + cardH + 22f
        text(c, "CAR RACING", width * .17f, t2 + cardH * .48f, width * .065f, yellow)
        text(c, "DODGE THE TRAFFIC", width * .17f, t2 + cardH * .69f, width * .027f, white)
        text(c, "BEST  $raceBest".replace("$raceBest", raceBest.toString()), width * .17f, t2 + cardH * .88f, width * .027f, yellow)
        text(c, ">", width * .84f, t2 + cardH * .65f, 42f, yellow, true)
        val y = height * .82f
        rect(c, width * .08f, y, width * .48f, y + 55f, Color.rgb(20, 48, 27))
        rect(c, width * .52f, y, width * .92f, y + 55f, Color.rgb(20, 48, 27))
        text(c, "SOUND ${if (soundOn) "ON" else "OFF"}", width * .28f, y + 36f, width * .033f, green, true)
        text(c, "MUSIC ${if (musicOn) "ON" else "OFF"}", width * .72f, y + 36f, width * .033f, green, true)
        text(c, "SETTINGS  •  ABOUT", width / 2f, height * .93f, width * .031f, white, true)
        text(c, "TAP A GAME TO PLAY", width / 2f, height * .975f, width * .026f, dimGreen, true)
    }

    private fun drawHeader(c: Canvas, title: String) {
        text(c, "‹ HOME", width * .06f, height * .075f, width * .04f, green)
        text(c, title, width / 2f, height * .075f, width * .055f, yellow, true)
        text(c, "Ⅱ", width * .92f, height * .075f, width * .055f, green, true)
        text(c, "SCORE  $score", width * .08f, height * .13f, width * .035f, white)
        text(c, "BEST  ${if (screen == Screen.SNAKE) snakeBest else raceBest}", width * .92f, height * .13f, width * .03f, yellow, true)
    }

    private fun drawSnakeScreen(c: Canvas) {
        drawHeader(c, "SNAKE")
        val boardSize = min(width * .84f, height * .49f)
        val cell = boardSize / 20f
        val left = (width - boardSize) / 2f
        val top = height * .20f
        rect(c, left - 5f, top - 5f, left + boardSize + 5f, top + boardSize + 5f, Color.rgb(21, 46, 27), 8f)
        p.color = Color.rgb(7, 20, 12)
        c.drawRect(left, top, left + boardSize, top + boardSize, p)
        for (i in 0..20) {
            p.color = Color.argb(30, 156, 255, 87); p.strokeWidth = 1f
            c.drawLine(left + i * cell, top, left + i * cell, top + boardSize, p)
            c.drawLine(left, top + i * cell, left + boardSize, top + i * cell, p)
        }
        rect(c, left + food.x * cell + 2, top + food.y * cell + 2, left + (food.x + 1) * cell - 2, top + (food.y + 1) * cell - 2, red, 3f)
        snake.forEachIndexed { i, part ->
            val inset = if (i == 0) 1f else 2f
            rect(c, left + part.x * cell + inset, top + part.y * cell + inset, left + (part.x + 1) * cell - inset, top + (part.y + 1) * cell - inset, if (i == 0) yellow else green, 3f)
        }
        drawDpad(c)
        if (mode == Mode.READY) text(c, "TAP TO START", width / 2f, height * .76f, width * .04f, white, true)
    }

    private fun drawDpad(c: Canvas) {
        val size = width * .15f
        val cy = height * .83f
        val cx = width / 2f
        val color = Color.rgb(24, 62, 34)
        rect(c, cx - size / 2, cy - size * 1.05f, cx + size / 2, cy - size * .05f, color, 12f)
        rect(c, cx - size / 2, cy + size * .05f, cx + size / 2, cy + size * 1.05f, color, 12f)
        rect(c, cx - size * 1.05f, cy - size / 2, cx - size * .05f, cy + size / 2, color, 12f)
        rect(c, cx + size * .05f, cy - size / 2, cx + size * 1.05f, cy + size / 2, color, 12f)
        text(c, "▲", cx, cy - size * .35f, size * .55f, green, true)
        text(c, "▼", cx, cy + size * .67f, size * .55f, green, true)
        text(c, "◀", cx - size * .55f, cy + size * .18f, size * .55f, green, true)
        text(c, "▶", cx + size * .55f, cy + size * .18f, size * .55f, green, true)
    }

    private fun drawRaceScreen(c: Canvas) {
        drawHeader(c, "CAR RACING")
        val roadL = width * .16f; val roadR = width * .84f
        p.color = Color.rgb(40, 43, 39); c.drawRect(roadL, height * .18f, roadR, height * .83f, p)
        p.color = yellow; p.strokeWidth = 5f
        c.drawLine(roadL, height * .18f, roadL, height * .83f, p)
        c.drawLine(roadR, height * .18f, roadR, height * .83f, p)
        val laneW = (roadR - roadL) / 3f
        p.color = Color.rgb(180, 180, 160); p.strokeWidth = 3f
        for (divider in 1..2) {
            var y = height * .18f + (roadOffset % 70f)
            while (y < height * .83f) {
                c.drawLine(roadL + divider * laneW, y, roadL + divider * laneW, y + 34f, p)
                y += 70f
            }
        }
        obstacles.forEach { drawCar(c, roadL + laneW * (it.lane + .5f), it.y, it.color, false) }
        drawCar(c, roadL + laneW * (lane + .5f), height * .70f, green, true)
        val btnY = height * .87f
        rect(c, width * .12f, btnY, width * .43f, btnY + height * .085f, Color.rgb(21, 54, 31), 16f)
        rect(c, width * .57f, btnY, width * .88f, btnY + height * .085f, Color.rgb(21, 54, 31), 16f)
        text(c, "◀ LEFT", width * .275f, btnY + height * .057f, width * .045f, green, true)
        text(c, "RIGHT ▶", width * .725f, btnY + height * .057f, width * .045f, green, true)
        if (mode == Mode.READY) text(c, "TAP TO START", width / 2f, height * .64f, width * .04f, white, true)
    }

    private fun drawCar(c: Canvas, centerX: Float, y: Float, color: Int, player: Boolean) {
        val w = width * .13f; val h = height * .085f
        rect(c, centerX - w / 2, y - h / 2, centerX + w / 2, y + h / 2, color, 8f)
        rect(c, centerX - w * .31f, y - h * .25f, centerX + w * .31f, y + h * .08f, if (player) Color.rgb(30, 62, 42) else Color.rgb(35, 43, 53), 5f)
        rect(c, centerX - w * .42f, y - h * .42f, centerX - w * .28f, y - h * .27f, Color.BLACK, 2f)
        rect(c, centerX + w * .28f, y - h * .42f, centerX + w * .42f, y - h * .27f, Color.BLACK, 2f)
        rect(c, centerX - w * .42f, y + h * .27f, centerX - w * .28f, y + h * .42f, Color.BLACK, 2f)
        rect(c, centerX + w * .28f, y + h * .27f, centerX + w * .42f, y + h * .42f, Color.BLACK, 2f)
    }

    private fun drawOverlay(c: Canvas) {
        rect(c, width * .12f, height * .34f, width * .88f, height * .66f, Color.argb(238, 4, 13, 8), 22f)
        val title = if (mode == Mode.PAUSED) "PAUSED" else "GAME OVER"
        text(c, title, width / 2f, height * .425f, width * .075f, if (mode == Mode.PAUSED) yellow else red, true)
        text(c, "SCORE  $score", width / 2f, height * .49f, width * .043f, white, true)
        text(c, "BEST  ${if (screen == Screen.SNAKE) snakeBest else raceBest}", width / 2f, height * .535f, width * .035f, green, true)
        text(c, if (mode == Mode.PAUSED) "TAP TO RESUME" else "TAP TO RESTART", width / 2f, height * .605f, width * .033f, yellow, true)
        text(c, "HOME", width / 2f, height * .645f, width * .028f, white, true)
    }

    private fun startGame(which: Screen) {
        screen = which; mode = Mode.READY; score = 0; elapsed = 0f
        if (which == Screen.SNAKE) {
            snake = mutableListOf(Cell(9, 10), Cell(8, 10), Cell(7, 10))
            direction = Cell(1, 0); queuedDirection = direction
            spawnFood()
        } else {
            lane = 1; targetLane = 1; obstacles.clear(); carSpawn = 0f; roadOffset = 0f
        }
        invalidate()
    }

    private fun beginCountdown() { mode = Mode.COUNTDOWN; countdown = 1.8f; sfx(1) }

    private fun spawnFood() {
        do { food = Cell(Random.nextInt(0, 20), Random.nextInt(0, 20)) } while (snake.contains(food))
    }

    private fun updateSnake(dt: Float) {
        snakeAccumulator += dt
        val interval = (0.17f - score * 0.0018f).coerceAtLeast(0.075f)
        while (snakeAccumulator >= interval && mode == Mode.PLAYING) {
            snakeAccumulator -= interval
            direction = queuedDirection
            val head = Cell(snake.first().x + direction.x, snake.first().y + direction.y)
            val eating = head == food
            if (head.x !in 0..19 || head.y !in 0..19 || snake.dropLast(if (eating) 0 else 1).contains(head)) {
                finishGame(); return
            }
            snake.add(0, head)
            if (eating) {
                score += 10; sfx(2); spawnFood()
            } else snake.removeAt(snake.lastIndex)
        }
    }

    private fun updateRace(dt: Float) {
        val speed = (height * (0.48f + score * 0.006f)).coerceAtMost(height * 1.15f)
        roadOffset = (roadOffset + speed * dt) % 70f
        carSpawn += dt
        val spawnEvery = (1.15f - score * .012f).coerceAtLeast(.48f)
        if (carSpawn >= spawnEvery) {
            carSpawn = 0f
            val available = (0..2).filter { l -> obstacles.none { it.lane == l && it.y < height * .34f } }
            if (available.isNotEmpty()) obstacles.add(Obstacle(available.random(), height * .18f - height * .08f, listOf(red, yellow, Color.CYAN).random()))
        }
        obstacles.forEach { it.y += speed * dt }
        val playerY = height * .70f
        if (obstacles.any { it.lane == lane && kotlin.math.abs(it.y - playerY) < height * .065f }) {
            finishGame(); return
        }
        obstacles.removeAll { it.y > height * .88f }
        score = (elapsed * 5f).toInt()
    }

    private fun finishGame() {
        mode = Mode.OVER
        if (screen == Screen.SNAKE && score > snakeBest) snakeBest = score
        if (screen == Screen.RACE && score > raceBest) raceBest = score
        save(); sfx(3)
    }

    private fun setDirection(dx: Int, dy: Int) {
        if (screen != Screen.SNAKE) return
        if (dx != -direction.x || dy != -direction.y) queuedDirection = Cell(dx, dy)
        if (mode == Mode.READY) beginCountdown()
    }

    private fun moveLane(delta: Int) {
        if (screen != Screen.RACE) return
        if (mode == Mode.READY) beginCountdown()
        targetLane = (targetLane + delta).coerceIn(0, 2)
        lane = targetLane
        sfx(1)
    }

    private var downX = 0f
    private var downY = 0f
    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> { downX = event.x; downY = event.y; return true }
            MotionEvent.ACTION_UP -> {
                val dx = event.x - downX; val dy = event.y - downY
                if (screen == Screen.HOME) {
                    val cardTop = height * .34f
                    if (downY in cardTop..(cardTop + height * .18f + 8f)) { startGame(Screen.SNAKE); beginCountdown() }
                    else if (downY in (cardTop + height * .18f + 8f)..(cardTop + height * .36f + 30f)) { startGame(Screen.RACE); beginCountdown() }
                    else if (downY in (height * .80f)..(height * .89f)) {
                        if (downX < width / 2) soundOn = !soundOn else musicOn = !musicOn
                        save(); sfx(1)
                    }
                    invalidate(); return true
                }
                if (mode == Mode.PAUSED || mode == Mode.OVER) {
                    if (downY > height * .62f && downY < height * .68f) { screen = Screen.HOME; mode = Mode.READY }
                    else if (mode == Mode.PAUSED) mode = Mode.PLAYING
                    else { startGame(screen); beginCountdown() }
                    invalidate(); return true
                }
                if (downY < height * .10f) {
                    if (downX < width * .22f) { screen = Screen.HOME; mode = Mode.READY }
                    else if (downX > width * .78f) mode = if (mode == Mode.PLAYING) Mode.PAUSED else Mode.PLAYING
                    invalidate(); return true
                }
                if (screen == Screen.SNAKE) {
                    if (kotlin.math.abs(dx) > 25 || kotlin.math.abs(dy) > 25) {
                        if (kotlin.math.abs(dx) > kotlin.math.abs(dy)) setDirection(if (dx > 0) 1 else -1, 0)
                        else setDirection(0, if (dy > 0) 1 else -1)
                    } else {
                        val cx = width / 2f; val cy = height * .83f; val sz = width * .15f
                        when {
                            downX in (cx - sz / 2)..(cx + sz / 2) && downY < cy -> setDirection(0, -1)
                            downX in (cx - sz / 2)..(cx + sz / 2) && downY > cy -> setDirection(0, 1)
                            downX < cx -> setDirection(-1, 0)
                            else -> setDirection(1, 0)
                        }
                    }
                    if (mode == Mode.READY) beginCountdown()
                } else {
                    if (dx < -25 || downX < width / 2) moveLane(-1) else moveLane(1)
                }
                invalidate(); return true
            }
        }
        return true
    }

    fun pauseForLifecycle() { if (mode == Mode.PLAYING || mode == Mode.COUNTDOWN) mode = Mode.PAUSED }
    fun resumeForLifecycle() { lastFrame = 0L; invalidate() }
    fun handleBack(): Boolean {
        if (screen != Screen.HOME) { screen = Screen.HOME; mode = Mode.READY; invalidate(); return true }
        return false
    }
}
