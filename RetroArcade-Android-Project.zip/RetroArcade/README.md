# RETRO ARCADE

A native Kotlin Android arcade collection featuring playable Snake and three-lane Car Racing.

## Requirements
- Android Studio (Koala or newer recommended)
- JDK 17
- Android SDK 35 (Android Studio can install it automatically)

## Build
1. Unzip the project.
2. Open the `RetroArcade` folder in Android Studio.
3. Allow Gradle sync to finish.
4. Connect an Android phone with USB debugging enabled, or start an emulator.
5. Press **Run**. To create an APK, choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. The debug APK is normally at `app/build/outputs/apk/debug/app-debug.apk`.

## Controls
- Home: tap Snake or Car Racing. Tap Sound/Music areas to toggle preferences.
- Snake: use the four-way on-screen pad or swipe. Avoid walls and your tail.
- Car Racing: tap LEFT/RIGHT or swipe to change lanes.
- In either game: tap the pause symbol at the top-right. Tap the overlay to resume/restart; tap HOME to return.
- Tap HOME at top-left during play to leave the game.

## Implementation notes
- Rendering and game loops use a custom Android `View` and Canvas.
- High scores and audio preferences use `SharedPreferences`.
- Sound effects use Android `ToneGenerator`; no external audio assets or permissions are required.
- The Music switch currently stores the preference for future soundtrack support. This source includes sound effects, not a bundled continuous music track.
- This project is supplied as source. It has not been built or device-tested in this environment; run Gradle sync/build in Android Studio and test on your target devices before release.
